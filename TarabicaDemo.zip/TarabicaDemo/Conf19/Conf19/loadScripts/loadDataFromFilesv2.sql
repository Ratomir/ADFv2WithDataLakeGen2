﻿USE movies;
DROP TABLE IF EXISTS genomescores;
CREATE TABLE if NOT EXISTS movies.genomescores 
(movieId INT, tagId INT, relevance DOUBLE)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
TBLPROPERTIES("skip.header.line.count"="1");
LOAD DATA INPATH 'wasbs://datastore@hdinsightsconf.blob.core.windows.net/input/genome-scores.csv' OVERWRITE INTO TABLE genomescores;
DROP TABLE IF EXISTS genometags;
CREATE TABLE if NOT EXISTS movies.genometags 
(tagId INT, tag STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
TBLPROPERTIES("skip.header.line.count"="1");
LOAD DATA INPATH 'wasbs://datastore@hdinsightsconf.blob.core.windows.net/input/genome-tags.csv' OVERWRITE INTO TABLE genometags;
DROP TABLE IF EXISTS links;
CREATE TABLE if NOT EXISTS movies.links 
(movieId int, imdbId string, tmdbId int)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
TBLPROPERTIES("skip.header.line.count"="1");
LOAD DATA INPATH 'wasbs://datastore@hdinsightsconf.blob.core.windows.net/input/links.csv' OVERWRITE INTO TABLE links;
DROP TABLE IF EXISTS movies;
CREATE TABLE if NOT EXISTS movies.movies 
(movieId int, title string, genres string)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
TBLPROPERTIES("skip.header.line.count"="1");
LOAD DATA INPATH 'wasbs://datastore@hdinsightsconf.blob.core.windows.net/input/movies.csv' OVERWRITE INTO TABLE movies;
DROP TABLE IF EXISTS ratings;
CREATE TABLE if NOT EXISTS movies.ratings 
(userId int, movieId int, rating DOUBLE, time TIMESTAMP)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
TBLPROPERTIES("skip.header.line.count"="1");
LOAD DATA INPATH 'wasbs://datastore@hdinsightsconf.blob.core.windows.net/input/ratings.csv' OVERWRITE INTO TABLE ratings;
DROP TABLE IF EXISTS tags;
CREATE TABLE if NOT EXISTS movies.tags 
(userId int, movieId int, tag string, time TIMESTAMP)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
STORED AS TEXTFILE
TBLPROPERTIES("skip.header.line.count"="1");
LOAD DATA INPATH 'wasbs://datastore@hdinsightsconf.blob.core.windows.net/input/tags.csv' OVERWRITE INTO TABLE tags;